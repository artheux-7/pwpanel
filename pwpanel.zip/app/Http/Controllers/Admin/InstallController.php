<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class InstallController extends Controller
{
    public function welcome()
    {
        return view('admin.install.welcome');
    }

    public function settings(Request $request)
    {
        if ($request->isMethod('post')) {
            $data = $request->only([
                'server_name', 'currency_name', 'server_ip', 
                'server_version', 'encryption_type'
            ]);
            Session::put('installer_settings', $data);
            return redirect()->route('admin.installer.complete');
        }

        return view('admin.install.steps', [
            'settings' => Session::get('installer_settings', [])
        ]);
    }

    public function environment(Request $request)
    {
        $env_config = Session::get('env_config', '');

        if ($request->isMethod('post')) {
            $env_config = $request->input('env_config', '');
            Session::put('env_config', $env_config);
            return redirect()->route('admin.installer.requirements');
        }

        return view('admin.install.environment', compact('env_config'));
    }

    public function requirements()
    {
        $requirements = [
            'requirements' => [
                'php' => function_exists('phpversion'),
                'pdo' => extension_loaded('pdo'),
                'mbstring' => extension_loaded('mbstring'),
            ]
        ];
        return view('admin.install.requirements', compact('requirements'));
    }

    public function permissions()
    {
        $folders = [
            ['folder' => storage_path(), 'isSet' => is_writable(storage_path()), 'permission' => 'Writable'],
            ['folder' => base_path('bootstrap/cache'), 'isSet' => is_writable(base_path('bootstrap/cache')), 'permission' => 'Writable']
        ];
        $permissions = ['permissions' => $folders];
        return view('admin.install.permissions', compact('permissions'));
    }

    public function complete()
    {
        $settings = Session::get('installer_settings', null);

        if (!$settings) {
            return redirect()->route('admin.installer.welcome');
        }

        try {
            // Jalankan migrasi dan seeding jika database terhubung
            \Artisan::call('migrate', ['--force' => true]);
            \Artisan::call('db:seed', ['--force' => true]);

            $message = [
                'status' => 'success',
                'text' => trans('install.complete.installed')
            ];
        } catch (\Exception $e) {
            $message = [
                'status' => 'error',
                'text' => $e->getMessage()
            ];
        }

        Session::flash('message', $message);

        return view('admin.install.complete');
    }
}
