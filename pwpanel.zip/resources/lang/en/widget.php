<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Widget Language Lines
    |--------------------------------------------------------------------------
    */

    'server_status_title' => 'Server Status',
    'server_status_online' => 'Online',
    'server_status_offline' => 'Offline',
    'players_online_title' => 'Players Online',
    'acc_registered_title' => 'Accounts Registered',
    'total_characters_title' => 'Characters Created',
    'total_factions_title' => 'Factions Created',
    'gms_title' => 'GM\'s Online'

];
