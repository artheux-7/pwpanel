<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Character Language Lines
    |--------------------------------------------------------------------------
    */
    'success' => 'You\'ve successfully selected a character.',
    'error' => [
        'role' => 'Can\'t get role.'
    ]


];
