<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Character Language Lines
    |--------------------------------------------------------------------------
    */
    'success' => 'Personagem selecionado.',
    'error' => [
        'role' => 'Não foi possível selecionar o personagem.'
    ]


];
