<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Widget Language Lines
    |--------------------------------------------------------------------------
    */

    'server_status_title' => 'Status do Servidor',
    'server_status_online' => 'Online',
    'server_status_offline' => 'Offline',
    'players_online_title' => 'Personagens Online',
    'acc_registered_title' => 'Contas Registradas',
    'total_characters_title' => 'Personagens Criados',
    'total_factions_title' => 'Clãs Criados',
    'gms_title' => 'GM\'s Online'

];
