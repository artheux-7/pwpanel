<!-- BEGIN INNER FOOTER -->
<div class="page-footer">
    <div class="container"> Support the developers of the panel.
        <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=R9FB8E4X5EYVC" target="_blank">Donate!</a>
    </div>
</div>
<div class="scroll-to-top">
    <i class="icon-arrow-up"></i>
</div>
<!-- END FOOTER -->