@extends('admin.install.header')

@section('content')
    <div class="col-md-4 col-md-offset-4">
        <ul class="list-group installer">
            @foreach( $permissions['permissions'] as $permission )
                <li class="list-group-item">
                    {{ $permission['folder'] }} 
                    <span>
                        <i class="fs20 icon-{{ $permission['isSet'] ? 'check font-green-jungle' : 'close font-red' }}"></i> 
                        {{ $permission['permission'] }}
                    </span>
                </li>
            @endforeach
        </ul>
        <div class="text-center mt-lg">
            <a class="btn btn-primary btn-lg" href="{{ route('admin.installer.complete') }}">{{ trans('install.continue') }}</a>
        </div>
    </div>
@endsection
