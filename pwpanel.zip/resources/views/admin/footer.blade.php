<div class="page-footer">
    <div class="page-footer-inner"> Support the developers.
        <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=R9FB8E4X5EYVC" target="_blank">Donate!</a>
    </div>
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>